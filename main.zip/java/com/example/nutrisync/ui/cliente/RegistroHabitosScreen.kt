package com.example.nutrisync.ui.cliente

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.nutrisync.data.RegistroRepository
import com.example.nutrisync.data.ThemePreference
import com.example.nutrisync.data.model.RegistroHabito
import com.example.nutrisync.network.AuthManager
import com.example.nutrisync.ui.components.TopBarWithThemeToggle
import kotlinx.coroutines.launch

@Composable
fun RegistroHabitosScreen(navController: NavController, onThemeChanged: (Boolean) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repository = remember { RegistroRepository(context) }
    val userId = AuthManager.getUserId(context) ?: ""
    val isEntrenador = AuthManager.getUserRole(context) == "entrenador"
    var isDark by remember { mutableStateOf(false) }

    var hizoEjercicio by rememberSaveable { mutableStateOf(false) }
    var desayuno by rememberSaveable { mutableStateOf(false) }
    var comida by rememberSaveable { mutableStateOf(false) }
    var cena by rememberSaveable { mutableStateOf(false) }
    var horasSueno by rememberSaveable { mutableStateOf("") }
    var peso by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(Unit) {
        isDark = ThemePreference.isDarkMode(context)
    }

    Scaffold(
        topBar = {
            TopBarWithThemeToggle(
                isDarkTheme = isDark,
                onToggleTheme = {
                    isDark = !isDark
                    scope.launch {
                        ThemePreference.setDarkMode(context, isDark)
                        onThemeChanged(isDark)
                    }
                },
                title = if (isEntrenador) "Registro para Cliente" else "Mis Hábitos"
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = hizoEjercicio, onCheckedChange = { hizoEjercicio = it })
                    Text("¿Hiciste ejercicio hoy?")
                }
            }

            item { Text("Comidas consumidas:") }

            items(listOf("Desayuno" to desayuno, "Comida" to comida, "Cena" to cena)) { (label, state) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = state, onCheckedChange = {
                        when (label) {
                            "Desayuno" -> desayuno = it
                            "Comida" -> comida = it
                            "Cena" -> cena = it
                        }
                    })
                    Text(label)
                }
            }

            item {
                OutlinedTextField(
                    value = horasSueno,
                    onValueChange = { horasSueno = it },
                    label = { Text("Horas de sueño") },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                Button(onClick = {
                    scope.launch {
                        val horas = horasSueno.toIntOrNull()
                        if (horas != null) {
                            repository.guardarRegistro(
                                RegistroHabito(
                                    userId = userId,
                                    hizoEjercicio = hizoEjercicio,
                                    desayuno = desayuno,
                                    comida = comida,
                                    cena = cena,
                                    horasSueno = horas,
                                    peso = peso.toFloatOrNull() ?: 0f,
                                    entrenadorId = if (isEntrenador) userId else null
                                ),
                                userId
                            )
                            Toast.makeText(context, "Hábitos guardados", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Ingresa horas de sueño válidas", Toast.LENGTH_SHORT).show()
                        }
                    }
                }) {
                    Text("Guardar hábitos")
                }
            }

            item {
                Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.primary)
            }

            item {
                OutlinedTextField(
                    value = peso,
                    onValueChange = { peso = it },
                    label = { Text("Peso actual (kg)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                Button(onClick = { navController.popBackStack() }) {
                    Text("Volver")
                }
            }
        }
    }
}
