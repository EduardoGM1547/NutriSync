package com.example.nutrisync.ui.cliente

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.nutrisync.data.NutriSyncDatabase
import com.example.nutrisync.data.RegistroHabito
import com.example.nutrisync.data.ThemePreference
import com.example.nutrisync.network.AuthManager
import com.example.nutrisync.ui.components.TopBarWithThemeToggle
import com.example.nutrisync.ui.utils.isLandscape
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun HistorialScreen(navController: NavController, onThemeChanged: (Boolean) -> Unit) {
    val context = LocalContext.current
    val db = remember { NutriSyncDatabase.getDatabase(context) }
    val scope = rememberCoroutineScope()
    var isDark by remember { mutableStateOf(false) }
    var registros by remember { mutableStateOf<List<RegistroHabito>>(emptyList()) }

    val landscape = isLandscape()

    LaunchedEffect(Unit) {
        isDark = ThemePreference.isDarkMode(context)
        val userId = AuthManager.getUserId(context)
        if (userId != null) {
            scope.launch(Dispatchers.IO) {
                registros = db.registroHabitoDao().obtenerTodos(userId).sortedBy { it.fecha }
            }
        }
    }

    Scaffold(
        topBar = {
            TopBarWithThemeToggle(
                isDarkTheme = isDark,
                onToggleTheme = {
                    isDark = !isDark
                    scope.launch {
                        ThemePreference.setDarkMode(context, isDark)
                        onThemeChanged(isDark)
                    }
                },
                title = "Historial de Hábitos"
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            if (landscape) {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(registros.chunked(2)) { fila ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            fila.forEach { registro ->
                                RegistroCard(registro, Modifier.weight(1f))
                            }
                        }
                    }
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(registros) { registro ->
                        RegistroCard(registro, Modifier.fillMaxWidth())
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { navController.popBackStack() },
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) {
                Text("Volver")
            }
        }
    }
}

@Composable
fun RegistroCard(registro: RegistroHabito, modifier: Modifier) {
    Card(
        modifier = modifier,
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text("Fecha: ${registro.fecha.take(10)}")
            Text("Ejercicio: ${if (registro.hizoEjercicio) "Sí" else "No"}")
            Text(
                "Comidas: " +
                        listOfNotNull(
                            if (registro.desayuno) "Desayuno" else null,
                            if (registro.comida) "Comida" else null,
                            if (registro.cena) "Cena" else null
                        ).joinToString(", ")
            )
            Text("Sueño: ${registro.horasSueno}h")
            Text("Peso: ${registro.peso} kg")
        }
    }
}