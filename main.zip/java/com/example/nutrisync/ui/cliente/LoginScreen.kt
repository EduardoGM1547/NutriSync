package com.example.nutrisync.ui.cliente

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.nutrisync.network.AuthManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(navController: NavController) {
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Bienvenido a NutriSync") }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(32.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp, Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("¿Cómo deseas ingresar?", style = MaterialTheme.typography.headlineSmall)

            Button(onClick = {
                AuthManager.login(context, "user123", "cliente", "token_cliente")
                navController.navigate("home")
                Toast.makeText(context, "Sesión de cliente iniciada", Toast.LENGTH_SHORT).show()
            }) {
                Text("Ingresar como Cliente")
            }

            Button(onClick = {
                AuthManager.login(context, "trainer123", "entrenador", "token_entrenador")
                navController.navigate("home")
                Toast.makeText(context, "Sesión de entrenador iniciada", Toast.LENGTH_SHORT).show()
            }) {
                Text("Ingresar como Entrenador")
            }
        }
    }
}