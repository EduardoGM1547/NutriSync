package com.example.nutrisync.ui.cliente


import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.nutrisync.network.AuthManager
import com.example.nutrisync.data.ThemePreference
import com.example.nutrisync.ui.components.TopBarWithThemeToggle
import com.example.nutrisync.ui.utils.frasesMotivacionales
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.absoluteValue

@Composable
fun HomeScreen(navController: NavController, onThemeChanged: (Boolean) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isDark by remember { mutableStateOf(false) }
    val userRole = AuthManager.getUserRole(context)

    LaunchedEffect(Unit) {
        isDark = ThemePreference.isDarkMode(context)
    }

    val fraseDelDia = if (frasesMotivacionales.isNotEmpty()) {
        val index = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())
            .hashCode().absoluteValue % frasesMotivacionales.size
        frasesMotivacionales[index]
    } else {
        "¡Cuida tu salud todos los días!"
    }

    Scaffold(
        topBar = {
            TopBarWithThemeToggle(
                isDarkTheme = isDark,
                onToggleTheme = {
                    isDark = !isDark
                    scope.launch {
                        ThemePreference.setDarkMode(context, isDark)
                        onThemeChanged(isDark)
                    }
                },
                title = "NutriSync - ${if (userRole == "entrenador") "Entrenador" else "Cliente"}"
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "💡 $fraseDelDia",
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            Button(onClick = { navController.navigate("registroHabitos") }) {
                Text(if (userRole == "entrenador") "Registrar hábitos para cliente" else "Registrar mis hábitos")
            }

            Button(onClick = { navController.navigate("historial") }) {
                Text("Ver historial")
            }

            Button(onClick = { navController.navigate("pesoGrafica") }) {
                Text("Ver gráfica de peso")
            }

            Button(onClick = { navController.navigate("perfil") }) {
                Text("Ver perfil")
            }

            if (userRole == "entrenador") {
                Button(onClick = { navController.navigate("clientes") }) {
                    Text("Ver mis clientes")
                }
            }
        }
    }
}

