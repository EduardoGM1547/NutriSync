package com.example.nutrisync.ui.cliente

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.nutrisync.data.NutriSyncDatabase
import com.example.nutrisync.data.PerfilUsuario
import com.example.nutrisync.data.ThemePreference
import com.example.nutrisync.ui.components.TopBarWithThemeToggle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun PerfilUsuarioScreen(navController: NavController, onThemeChanged: (Boolean) -> Unit) {
    val context = LocalContext.current
    val db = remember { NutriSyncDatabase.getDatabase(context) }
    val scope = rememberCoroutineScope()
    var isDark by remember { mutableStateOf(false) }

    var nombre by remember { mutableStateOf("") }
    var edad by remember { mutableStateOf("") }
    var altura by remember { mutableStateOf("") }
    var objetivo by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        isDark = ThemePreference.isDarkMode(context)
        val existente = db.perfilUsuarioDao().obtener()
        existente?.let {
            nombre = it.nombre
            edad = it.edad.toString()
            altura = it.altura.toString()
            objetivo = it.objetivo
        }
    }

    Scaffold(
        topBar = {
            TopBarWithThemeToggle(
                isDarkTheme = isDark,
                onToggleTheme = {
                    isDark = !isDark
                    scope.launch {
                        ThemePreference.setDarkMode(context, isDark)
                        onThemeChanged(isDark)
                    }
                },
                title = "Perfil de Usuario"
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = nombre,
                onValueChange = { nombre = it },
                label = { Text("Nombre") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = edad,
                onValueChange = { edad = it },
                label = { Text("Edad") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = altura,
                onValueChange = { altura = it },
                label = { Text("Altura (cm)") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = objetivo,
                onValueChange = { objetivo = it },
                label = { Text("Objetivo personal") },
                modifier = Modifier.fillMaxWidth()
            )

            Button(onClick = {
                val edadInt = edad.toIntOrNull()
                val alturaFloat = altura.toFloatOrNull()

                if (nombre.isNotBlank() && edadInt != null && alturaFloat != null) {
                    val perfil = PerfilUsuario(
                        id = 1,
                        nombre = nombre,
                        edad = edadInt,
                        altura = alturaFloat,
                        objetivo = objetivo
                    )

                    scope.launch(Dispatchers.IO) {
                        db.perfilUsuarioDao().insertar(perfil)
                        launch(Dispatchers.Main) {
                            Toast.makeText(context, "Perfil guardado correctamente", Toast.LENGTH_SHORT).show()
                        }
                    }
                } else {
                    Toast.makeText(context, "Completa todos los campos correctamente", Toast.LENGTH_SHORT).show()
                }
            }) {
                Text("Guardar")
            }

            Button(onClick = { navController.popBackStack() }) {
                Text("Volver")
            }
        }
    }
}
