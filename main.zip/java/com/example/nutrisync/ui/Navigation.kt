package com.example.nutrisync.ui

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import com.example.nutrisync.ui.cliente.*

@Composable
fun AppNavigation(
    navController: NavHostController,
    isDarkTheme: Boolean,
    onToggleTheme: (Boolean) -> Unit
) {
    NavHost(navController = navController, startDestination = "login") {
        composable("login") {
            LoginScreen(navController)
        }
        composable("home") {
            HomeScreen(
                navController = navController,
                onThemeChanged = { isDark -> onToggleTheme(isDark) }
            )
        }
        composable("registroHabitos") {
            RegistroHabitosScreen(
                navController = navController,
                onThemeChanged = { isDark -> onToggleTheme(isDark) }
            )
        }
        composable("historial") {
            HistorialScreen(
                navController = navController,
                onThemeChanged = { isDark -> onToggleTheme(isDark) }
            )
        }
        composable("pesoGrafica") {
            PesoGraficaScreen(
                navController = navController,
                onThemeChanged = { isDark -> onToggleTheme(isDark) }
            )
        }
        composable("perfil") {
            PerfilUsuarioScreen(
                navController = navController,
                onThemeChanged = { isDark -> onToggleTheme(isDark) }
            )
        }
    }
}