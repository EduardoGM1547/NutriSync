package com.example.nutrisync.ui.utils

val frasesMotivacionales = listOf(
    "¡Hoy es un gran día para cuidar tu salud!",
    "Sigue así, estás haciendo un gran trabajo.",
    "Cada paso cuenta, ¡no te detengas!",
    "Una comida saludable a la vez.",
    "Tú puedes lograr tus metas.",
    "Recuerda: constancia, no perfección."
)
