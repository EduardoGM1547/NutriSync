package com.example.nutrisync

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import androidx.navigation.compose.rememberNavController
import com.example.nutrisync.data.dataStore
import com.example.nutrisync.ui.AppNavigation
import com.example.nutrisync.ui.theme.NutriSyncTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val context = this
        val darkModeKey = booleanPreferencesKey("dark_mode")
        val isDarkModeDefault = runBlocking {
            context.dataStore.data.first()[darkModeKey] ?: false
        }

        setContent {
            var isDarkTheme by remember { mutableStateOf(isDarkModeDefault) }

            NutriSyncTheme(darkTheme = isDarkTheme) {
                val navController = rememberNavController()

                AppNavigation(
                    navController = navController,
                    isDarkTheme = isDarkTheme,
                    onToggleTheme = { isDark ->
                        isDarkTheme = isDark
                        runBlocking {
                            context.dataStore.edit { prefs ->
                                prefs[darkModeKey] = isDarkTheme
                            }
                        }
                    }
                )
            }
        }
    }
}