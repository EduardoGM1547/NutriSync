package com.example.nutrisync.data.db

import androidx.room.*
import com.example.nutrisync.data.model.PerfilUsuario

@Dao
interface PerfilUsuarioDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertar(perfil: PerfilUsuario)

    @Query("SELECT * FROM PerfilUsuario WHERE id = 1 LIMIT 1")
    suspend fun obtener(): PerfilUsuario?
}
