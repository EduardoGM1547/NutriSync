package com.example.nutrisync.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.nutrisync.data.model.PerfilUsuario
import com.example.nutrisync.data.model.RegistroHabito

@Database(
    entities = [RegistroHabito::class, PerfilUsuario::class],
    version = 1,
    exportSchema = false
)
abstract class NutriSyncDatabase : RoomDatabase() {
    abstract fun registroHabitoDao(): RegistroHabitoDao
    abstract fun perfilUsuarioDao(): PerfilUsuarioDao

    companion object {
        @Volatile
        private var INSTANCE: NutriSyncDatabase? = null

        fun getDatabase(context: Context): NutriSyncDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    NutriSyncDatabase::class.java,
                    "nutrisync_db"
                ).fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
