package com.example.nutrisync.data.model


import androidx.room.Entity
import androidx.room.PrimaryKey
import java.text.SimpleDateFormat
import java.util.*

@Entity
data class RegistroHabito(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val userId: String,
    val entrenadorId: String? = null,
    val fecha: String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
    val hizoEjercicio: Boolean,
    val desayuno: Boolean,
    val comida: Boolean,
    val cena: Boolean,
    val horasSueno: Int,
    val peso: Float,
    val sincronizado: Boolean = false,
    val fechaModificacion: String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
)