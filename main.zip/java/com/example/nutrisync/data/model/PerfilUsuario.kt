package com.example.nutrisync.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class PerfilUsuario(
    @PrimaryKey val id: Int = 1,
    val nombre: String,
    val edad: Int,
    val altura: Float,
    val objetivo: String
)