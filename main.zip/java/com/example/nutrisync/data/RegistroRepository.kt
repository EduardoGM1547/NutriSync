package com.example.nutrisync.data

import android.content.Context
import com.example.nutrisync.data.db.NutriSyncDatabase
import com.example.nutrisync.data.model.RegistroHabito

class RegistroRepository(context: Context) {
    private val registroDao = NutriSyncDatabase.getDatabase(context).registroHabitoDao()

    suspend fun guardarRegistro(registro: RegistroHabito, userId: String) {
        registroDao.insertar(registro)
    }

    suspend fun obtenerTodos(userId: String): List<RegistroHabito> {
        return registroDao.obtenerTodos(userId)
    }
}