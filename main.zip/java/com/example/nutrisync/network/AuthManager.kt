package com.example.nutrisync.network

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.runBlocking

val Context.authDataStore by preferencesDataStore(name = "auth")

object AuthManager {
    private val USER_ID_KEY = stringPreferencesKey("user_id")
    private val USER_ROLE_KEY = stringPreferencesKey("user_role")
    private val USER_TOKEN_KEY = stringPreferencesKey("user_token")

    fun login(context: Context, userId: String, role: String, token: String) {
        runBlocking {
            context.authDataStore.edit { preferences ->
                preferences[USER_ID_KEY] = userId
                preferences[USER_ROLE_KEY] = role
                preferences[USER_TOKEN_KEY] = token
            }
        }
    }

    fun logout(context: Context) {
        runBlocking {
            context.authDataStore.edit { preferences ->
                preferences.clear()
            }
        }
    }

    fun getUserId(context: Context): String? {
        return runBlocking {
            context.authDataStore.data.map { it[USER_ID_KEY] }.first()
        }
    }

    fun getUserRole(context: Context): String? {
        return runBlocking {
            context.authDataStore.data.map { it[USER_ROLE_KEY] }.first()
        }
    }

    fun getToken(context: Context): String? {
        return runBlocking {
            context.authDataStore.data.map { it[USER_TOKEN_KEY] }.first()
        }
    }

    fun isLoggedIn(context: Context): Boolean {
        return getUserId(context) != null
    }
}