package com.example.nutrisync.network


import com.example.nutrisync.data.PerfilUsuario
import com.example.nutrisync.data.RegistroHabito
import retrofit2.Response
import retrofit2.http.*

interface ApiService {
    @GET("registros/{userId}")
    suspend fun obtenerRegistros(@Path("userId") userId: String): Response<List<RegistroHabito>>

    @POST("registros")
    suspend fun crearRegistro(@Body registro: RegistroHabito): Response<RegistroHabito>

    @PUT("registros/{id}")
    suspend fun actualizarRegistro(@Path("id") id: String, @Body registro: RegistroHabito): Response<RegistroHabito>

    @GET("perfil/{userId}")
    suspend fun obtenerPerfil(@Path("userId") userId: String): Response<PerfilUsuario>

    @POST("perfil")
    suspend fun guardarPerfil(@Body perfil: PerfilUsuario): Response<PerfilUsuario>

    @GET("registros/entrenador/{entrenadorId}")
    suspend fun obtenerRegistrosEntrenador(@Path("entrenadorId") entrenadorId: String): Response<List<RegistroHabito>>
}
