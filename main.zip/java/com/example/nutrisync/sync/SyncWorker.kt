package com.example.nutrisync.sync

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.nutrisync.network.AuthManager
import com.example.nutrisync.data.RegistroRepository
import com.example.nutrisync.ui.utils.showSyncNotification
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class SyncWorker(
    context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val userId = AuthManager.getUserId(applicationContext)
                ?: return@withContext Result.failure()

            val repository = RegistroRepository(applicationContext)

            val unsynced = repository.getUnsyncedRecords(userId)
            if (unsynced.isNotEmpty()) {
                repository.syncRecordsToCloud(unsynced)
            }

            repository.syncFromCloud(userId)

            applicationContext.showSyncNotification(
                "Sincronización completada",
                "${unsynced.size} registros sincronizados"
            )

            Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            applicationContext.showSyncNotification(
                "Error en sincronización",
                "Reintentando en 2 horas"
            )
            Result.retry()
        }
    }
}